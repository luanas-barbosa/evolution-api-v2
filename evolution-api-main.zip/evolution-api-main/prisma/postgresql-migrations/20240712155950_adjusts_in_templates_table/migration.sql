-- DropIndex
DROP INDEX "Template_instanceId_key";
